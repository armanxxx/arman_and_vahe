class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
